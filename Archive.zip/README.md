# Global-Game-Jam-18
Pathogen Defense
You are the red blood cell and you are defending the red blood cells from the pathogens
