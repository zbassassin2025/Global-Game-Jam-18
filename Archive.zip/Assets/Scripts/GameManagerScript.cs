﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManagerScript: MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {


		//check to see if player is alive (white blood cell != 0)

		//check to see if the number of red blood cell != 0

		//check to see if the number of enemy cell != 0

			//check to see if a Menu key is pressed (Pause Menu)


	}
}
